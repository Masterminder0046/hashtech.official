# Hash_Tech — Portfolio + Lead Generation Website

A mobile-first freelance website for **Sheik Mohamed / Hash_Tech**, written with HTML, CSS and plain JavaScript. No React, Python server, package manager or build step is required.

## What's included

```
hash_tech_site/
├── index.html                 Main site, accessible sections, SEO metadata, JSON-LD
├── style.css                  All layouts, mobile responsiveness, light/dark mode
├── script.js                  Navigation, theme, scroll effects, cursor, contact form
├── thanks.html                Branded fallback confirmation after form POST
├── sitemap.xml                Search-engine sitemap; requires your domain
├── robots.txt                 Crawler rules; requires your domain
├── _headers                   Optional Netlify security headers
├── README.md
└── assets/
    ├── hash-tech-logo.png    Your official logo, with transparent outside background
    ├── favicon.ico           Original logo uploaded in ICO format
    ├── apple-touch-icon.png  Home-screen icon for Apple devices
    └── og-cover.png          Social sharing image featuring your logo (1200 × 630)
```

## Preview locally

1. Unzip the folder and open a terminal in it.
2. Run `python -m http.server 8000` (or `py -m http.server 8000` on Windows).
3. Visit `http://localhost:8000` in your browser.
4. Test responsive layout using browser device emulation. Test the menu, theme, WhatsApp links and keyboard focus.

**Important:** Netlify Forms cannot send a real enquiry from a local server. The local preview intentionally displays a clear notice instead of pretending to submit it. Submit a test enquiry *after* Netlify deployment.

## Deploy free using Netlify + GitHub (recommended)

1. Create a new GitHub repository. Upload all files in this directory to the **repository root**, not inside a second folder.
2. On Netlify, choose **Add new project → Import an existing project → GitHub**, select the repository and authorize it.
3. Framework/build command: **none**. Publish directory: `.` (the repository root). Choose **Deploy**.
4. Under **Forms**, switch on form detection if it is not already on. Deploy again if you enabled it after the first upload. Netlify identifies the static form `hash-tech-contact` at deploy time.
5. Submit a *real test form* on your new `*.netlify.app` URL. Check **Netlify → Forms → hash-tech-contact**. You can configure notification emails in Netlify's form notifications settings. Verify the thank-you page too (submit with JavaScript disabled for fallback).
6. Future GitHub pushes will automatically deploy. The free plan has usage limits for site bandwidth, requests and production deploys; check your Netlify usage screen. Form submissions are currently free on credit-based plans.

Official docs:
- https://docs.netlify.com/start/quickstarts/deploy-from-repository/
- https://docs.netlify.com/manage/forms/setup/
- https://docs.netlify.com/manage/forms/usage-and-billing/

### Why Netlify, not GitHub Pages?

GitHub Pages can host this site's HTML/CSS/JS, but cannot process the built-in contact form. On Vercel or Render, you'd need to connect another contact-form backend or service. Netlify handles both static hosting and the form.

## Connect your own domain

1. Purchase a domain at the registrar of your choice.
2. In Netlify, open **Domain management → Add a domain → Add a domain you already own**.
3. Follow the exact DNS instructions shown. You can use Netlify DNS or your external registrar's DNS. Wait until verification and HTTPS complete.
4. Replace **every** `YOUR-DOMAIN.example` in these files with your actual production domain (including protocol `https://`):
   - `index.html` (canonical, Open Graph URL/image, Twitter image, JSON-LD)
   - `sitemap.xml`
   - `robots.txt`
5. Commit and push again. Test `https://yourdomain.com/sitemap.xml`, `robots.txt`, the social preview, and the contact form.

Official docs: https://docs.netlify.com/manage/domains/manage-domains/assign-a-domain-to-your-site-app/

## Add Google Analytics 4

1. Visit https://analytics.google.com and create a GA4 property, then create a **Web** data stream for the live domain.
2. Get the measurement ID beginning with `G-`.
3. Find the `GOOGLE ANALYTICS` comment near the end of `index.html` and paste Google's exact provided tag (the script tags) into the HTML `<head>` as Google instructs. Do **not** replace it with a fake ID.
4. If you want visits on `thanks.html` tracked too, add the same tag to that file.
5. Open the live website and inspect GA4 **Realtime** to verify tracking. Consider a consent banner if your audience/legal requirements call for one.

Official docs: https://support.google.com/analytics/answer/9304153

## Add Google Search Console

1. Visit https://search.google.com/search-console and add your real domain as a property.
2. Complete ownership verification (DNS TXT is standard for a Domain property).
3. Open **Sitemaps**, enter `sitemap.xml` and submit.
4. Use **URL Inspection** for your main homepage. Indexing is not guaranteed and can take time.
5. Once launched, write detailed, genuine case studies and add dedicated pages for coaching-institute website design to increase useful search content. Avoid duplicate location pages.

Official docs: https://support.google.com/webmasters/answer/7451001

## Replace and personalize before publishing

- **Official logo:** your supplied `#TECH` logo has already been installed as the header/footer image, browser favicon, Apple touch icon and social preview. To change it later, replace the files in `assets/` and update the `src` references if you rename them.
- **Website domain:** update the explicit placeholder URLs in HTML, sitemap and robots.
- **Client testimonials:** find `PLACEHOLDER / CLIENT VOICES` in `index.html`; replace only when you receive genuine permission to publish a real quote. Don't invent names or ratings.
- **Workshop evidence:** find `PLACEHOLDER / WORKSHOP IMPACT`; insert dates, topics, institutions and participant numbers *only when verified*.
- **Portfolio visuals:** the custom card art is deliberately labelled `PROJECT ILLUSTRATION`, not a screenshot. Replace it with real screenshots or detailed case-study pages later.
- **Live project status:** periodically test Render project links. Free hosts sometimes need to wake up or projects may be unavailable.
- **Contact endpoint:** Netlify hosts this form automatically once detection is on. If deploying elsewhere, you **must replace the submit integration** with a working provider or backend.
- **Analytics ID:** optional; add your genuine GA4 code.
- **Email/WhatsApp:** the provided address and phone are already filled in. The WhatsApp link includes a ready-made booking message.

## Testing checklist

- [ ] Homepage loads at widths 320, 375, 768, 1024 and 1440px without horizontal scrolling.
- [ ] Tab key can reach nav, theme toggle, all project links, social icons and all form fields.
- [ ] Mobile menu opens, closes on link selection and closes with Escape.
- [ ] Light/dark toggle works and persists after refresh.
- [ ] Project links open the intended URLs; CampusOS is *not* clickable.
- [ ] WhatsApp opens the intended number with prefilled text.
- [ ] Submit a form on the deployed site and verify it appears in the Netlify Forms dashboard.
- [ ] Invalid/missing form fields are blocked by the browser.
- [ ] Turn JavaScript off and submit on Netlify to confirm the custom thank-you page.
- [ ] No made-up testimonials, workshop counts or service prices.
- [ ] Reduced-motion users do not see forced animations or custom cursor.
- [ ] Replace all `YOUR-DOMAIN.example` instances before launch.

## Design / code notes

Design variables are at the beginning of `style.css`. Sections in `index.html` are labelled with comments and semantic headings. The form script is at the end of `script.js`, and all animations degrade gracefully when JavaScript is disabled or motion is reduced. Icons are requested from a pinned Lucide CDN version; the page remains usable if the CDN is unavailable. Search engines may take time to rank a newly launched site, and metadata alone does not guarantee rankings.
